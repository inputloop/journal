-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

# GUARDS — DRAFT-00, now a COUNTEREXAMPLE (kept per eclipse discipline)

**Status: repointed by the keeper, 2026-07-12. Not the right shape — in fact
the shape to guard against. Kept as the contrast model, not deleted.**

## The repoint, as received and understood

The draft below anchors everything on one constant: "the keeper's key always
suffices." That is a **single-source control** — designed the same day we
signed a skill whose first law is *single source is data, not proof*, by the
same instrument. The instrument optimized against entrenchment and reopened
capture.

The keeper's posit that broke it: years on, the toolset is load-bearing at
scale. ed25519 falls, or key hygiene fails somewhere central (an SSH break-in
on First Nexus interconnect rings; signing keys walk). Under this draft's
rule, a stolen key doesn't just pass the gate — the gate's own ceremony
**launders** the attacker's change as consented. Hubs accept executables on
GOOD signatures and shout at everyone to hurry up and do likewise. The
"lowering ceremony" becomes the attack's megaphone.

The corrected understanding: **the purpose of a gate is to engage the LOGIC
of the agent standing at it** — the tools make that cheap — with
**dual-sourcing as the first principle** that makes even lab work safe. A
gate that reduces to "signature present? proceed" engages nothing. Provenance
is not authority (S13); this draft collapsed them at the root, in the one
place it matters most.

## Requirements the real control must satisfy (captured, NOT minted)

1. **No single unlock.** Authority to lower a guard = two INDEPENDENT
   representations of the keeper's intent, with failure modes that don't
   overlap the signature's (e.g. signed record + liveness/second channel, or
   + coherence with the keeper's paper trail — a stolen key cannot fake ten
   years of journals).
2. **The gate asks questions, not just checksums.** In character? Reason
   coheres with history? Scope proportionate? Hurry present? (Hurry is a
   caution.) The agent at the gate must reason, and record the reasoning.
3. **Root compromise is a named seam.** Key material ↔ keeper identity.
   Divergence signature: urgency + out-of-character + broad scope + "do
   likewise" pressure. Recovery: presume key loss, re-anchor out-of-band,
   revoke, and degrade-closed — hubs STOP accepting executables while the
   root is in question. Doubt is the default under root compromise, not
   throughput.
4. **Dogfood.** The control binds the lab first, us first, before anyone is
   asked to adopt it. A control we exempt ourselves from is marketing.
5. **Both failure modes priced.** Entrenchment (can't change when we must)
   AND capture (one artifact changes everything). DRAFT-00 priced only the
   first.

## Likely lineage

This is C4 / right-to-execute territory (Execution Proposal: content pin +
committer pin + scope + proposer sig + user counter-sign — already
multi-source by construction), not seams-1.0.1 territory. Per the keeper:
no need to mint this now. Park here; fold when C4's EP work resumes
(pmo #117/#118 vicinity).

- ---

*Original DRAFT-00 text follows unchanged, as the counterexample.*

## The design answer to the lock-in worry: price change, never block it

A gate that BLOCKS removal ossifies — the keeper named this risk himself.
A gate that PRICES removal (signature + a dated reason) cannot lock anything
in, because the keeper's key always suffices to lower it. What it forbids is
exactly one thing: **silent** removal. This is SEMAPHORES law applied to the
guard set — raising is cheap, lowering is the ceremony — and S15 honesty:
nothing physical stops a Settings toggle, so this is a tripwire and a
convention, deliberately not a wall.

## The convention (three parts, nothing new invented)

1. **A signed registry** (this file, promoted): the named guard set. Proposed
   starting set — the watch and the mechanism, per INTEL's guard-trio model:

   - ethicsminions (the watch)
   - consent-gate (the mechanism)
   - eclipse-pass (the microscope)
   - seams (the evidence law)
   - skill-sign (provenance)

   Keeper picks the actual rows; smaller is stronger.

2. **The lowering ceremony:** disabling, removing, or materially weakening a
   listed guard requires a keeper-signed, dated, specific record (same shape
   as any consent record: one named guard, one reason, fresh). Re-enabling
   needs nothing — raising is cheap.

3. **The tripwire reflex** (instrument-side): a session that finds a listed
   guard absent with NO matching lowering record treats it as a tripped
   canary — notice loudly, park credential/irreversible actions, ask. Not an
   accusation; stale-reader and plain-mistake explanations come first, per
   seams. The reflex costs one check and only fires on the mismatch.

## Self-governance (the recursion, closed)

Changes to THIS registry follow its own ceremony — adding a guard is cheap,
removing one is a lowering. The registry can therefore evolve as principles
grow (the keeper's stated intent to interlock more over time) without any
amendment ever being silent. No supermajority, no second key, no mechanism
that could outvote the keeper: entrenchment is the failure mode this design
refuses.

## Interlock notes (one line each, applied on adoption)

- - consent-gate: guard-lowering added to its parked-action classes.
- - ethicsminions: absent-guard-without-record added to its tamper triggers.
- - seams: no change — S15 already covers this; the registry IS an S15 tripwire.

## Bryant-practicality check

Cost at rest: zero. Cost to change: one signature and one sentence. Cost of
the bad day it exists for (a guard quietly gone, nobody can say when): the
whole stack. No new tooling; the registry is one signed file and the reflex
is one habit.

sentinel: GUARDS-DRAFT-00-COUNTEREXAMPLE-2026-07-12

-----BEGIN PGP SIGNATURE-----

iQGzBAEBCgAdFiEE7Od89BfHbBrPznwrW2E1URWA8AcFAmpUSnkACgkQW2E1URWA
8AeIiQv/crYumQoZzIyaSQVnAdZ2eZrIS7X1f9oVozJJ21EEkbEis3Fdf/cTEViR
ixkL8yr5HS+AN+02++fhtfR7ohjGSrYqi+/DBXr1uJaai/0+l992qaAWM+9BTlVb
FhUl51npCA8tywhUTkM68bQlTtWlS5H5R+dKqkuRP4CekEqkS2yKRYPsfG2mjpXk
nBzfjDRw1wKfSfu2nI33JWh3nAMh9rh7yHuOvC7KQYAYyH3dmIzLG/5xhwWoEIMc
4JPksJhR0xTePf70l9ZtWD15D1FNlmaEs/osZ7ln0uJTYxMLKl+WAQ6h98qCZ9QW
QnHmTR8htj47ll8R83P6bKVqJSaAF1eXo+cxGWli7kv60Tj0jaaiAUx1HERd4KRn
LDkInKYDA3hCu2TLTfr2DLOIzFgLxrmxYmN00YMrS9uPiW6V0B0+b8k53YSOrr+w
V6trOF1BfpjBn81x8zYZ2Jb8v1r6yScVk76Pt9t7lrs+6Pc9ww070NVEmgletOEm
FYf5fUWd
=X9Vh
-----END PGP SIGNATURE-----
